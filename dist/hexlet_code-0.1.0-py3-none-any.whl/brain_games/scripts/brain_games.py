#!/usr/bin/env python3
from brain_games import eng


def main():
    eng.welcome_user()


if __name__ == '__main__':
    main()
