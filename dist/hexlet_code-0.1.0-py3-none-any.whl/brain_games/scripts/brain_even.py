from brain_games.engine import start_game
from brain_games.games import br_evens

def main():
    start_game()


if __name__ == '__main__':
    main()
