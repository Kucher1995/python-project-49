from random import randrange
from brain_games import cli
from brain_games import phras


if __name__ == '__main__':
    main()
