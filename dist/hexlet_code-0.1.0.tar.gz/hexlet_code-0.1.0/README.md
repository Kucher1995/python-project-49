### Hexlet tests and linter status:
[![Actions Status](https://github.com/Kucher1995/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Kucher1995/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/cdcbd97debeeb76dfc6e/maintainability)](https://codeclimate.com/github/Kucher1995/python-project-49/maintainability)
https://asciinema.org/a/yGFM6qn0UGzvHZbYnhCFTcrWv
