#!/usr/bin/env python3
from brain_games import engine


def main():
    engine.welcome_user()


if __name__ == '__main__':
    main()
